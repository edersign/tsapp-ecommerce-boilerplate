# E-commerce Boilerplate

This is a boilerplate for an e-commerce frontend using Vite, React, TanStack Router, TanStack Query, and Zustand.

## Installation

```bash
npm install
```

## Development

```bash
npm run dev
```

## Build

```bash
npm run build
```